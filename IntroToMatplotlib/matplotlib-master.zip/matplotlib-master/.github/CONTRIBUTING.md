Please refer to the [developers guide](https://matplotlib.org/devel/index.html).
