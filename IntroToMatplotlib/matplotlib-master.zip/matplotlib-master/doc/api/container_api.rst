************************
``matplotlib.container``
************************

.. automodule:: matplotlib.container
   :members:
   :undoc-members:
   :show-inheritance:
