***********************
``matplotlib.mathtext``
***********************

.. inheritance-diagram:: matplotlib.mathtext
   :parts: 1

.. automodule:: matplotlib.mathtext
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: Box, Char, ComputerModernFontConstants, DejaVuSansFontConstants, DejaVuSerifFontConstants, FontConstantsBase, Fonts, Glue, Kern, Node, Parser, STIXFontConstants, STIXSansFontConstants, Ship, StandardPsFonts, TruetypeFonts
