
:mod:`matplotlib.backends.backend_nbagg`
========================================

.. automodule:: matplotlib.backends.backend_nbagg
   :members:
   :undoc-members:
   :show-inheritance:
