*********************
``matplotlib.ticker``
*********************

.. automodule:: matplotlib.ticker
   :members:
   :undoc-members:
   :show-inheritance:


.. inheritance-diagram:: matplotlib.ticker
   :parts: 1
