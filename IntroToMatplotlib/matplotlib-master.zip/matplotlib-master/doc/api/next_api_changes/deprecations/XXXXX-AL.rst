``matplotlib.streamplot.get_integrator``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
... is deprecated.
