
:mod:`matplotlib.backends.backend_webagg`
=========================================

.. note::
   The WebAgg backend is not documented here, in order to avoid adding Tornado
   to the doc build requirements.

.. module:: matplotlib.backends.backend_webagg
