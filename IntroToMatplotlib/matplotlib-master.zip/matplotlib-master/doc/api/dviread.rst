**********************
``matplotlib.dviread``
**********************

.. automodule:: matplotlib.dviread
   :members:
   :undoc-members:
   :exclude-members: Page, Text, Box
   :show-inheritance:
