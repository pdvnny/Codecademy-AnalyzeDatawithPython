Removing points on a PolygonSelector
------------------------------------
After completing a `~matplotlib.widgets.PolygonSelector`, individual
points can now be removed by right-clicking on them.
